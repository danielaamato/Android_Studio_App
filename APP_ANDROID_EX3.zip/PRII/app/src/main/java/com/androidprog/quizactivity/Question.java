package com.androidprog.quizactivity;

public class Question {
    private String question;
    private int correct;
    private String[] option;

    public Question(String question, String[] option, int correct)
    {
        this.question = question;
        this.option = option;
        this.correct = correct;
    }

    public String getQuestion()
    {
        return question;
    }

    public int getCorrect()
    {
        return correct;
    }

    public String[] getOption()
    {
        return option;
    }
}

