package com.androidprog.quizactivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    private static final String TAG = "LogLifecycleCallbacks";
    private static final String KEY_INDEX = "index";
    private static final String BOOL = "bool";

    private String answerShown = "false";
    private String mCurrentbool;
    private Button bResposta1;
    private Button bResposta2;
    private Button bResposta3;
    private Button bResposta4;

    private Button newAct;
    private View rootView;
    private TextView questionOne, moneyAtrib;
    private ImageView imagenView;
    private int mCurrentIndex;
    private static final String MONEY = "moneyAtribKey";

    String[] imagenes = {
            "francia",
            "mapa",
            "mat",
            "madrid"
    };
    int money;
    private int id = 0;

    private Question[] questions = {
            new Question("¿Cual es la capital de francia?", new String[]{"Madrid", "Paris", "Londres", "Roma"}, 2),
            new Question("¿Cuantos continentes existen?", new String[]{"Uno", "Cuatro", "Tres", "Cinco"}, 4),
            new Question("¿Cuanto es 2 mas 2?", new String[]{"Cuatro", "Seis", "Nueve", "Dos"}, 1),
            new Question("¿Que ciudad es mas grande?", new String[]{"Malaga", "Madrid", "Bcn", "Valencia"}, 2)
    };

    @SuppressLint({"MissingInflatedId", "ResourceType"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate(Bundle) called");

        setContentView(R.layout.activity_main);

        if (savedInstanceState != null)
        {
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
            id = mCurrentIndex;
            money = savedInstanceState.getInt(MONEY, 0);
            mCurrentbool = savedInstanceState.getString(BOOL, "false");
            answerShown = mCurrentbool;
        } else
        {
            mCurrentIndex = 0;
            money = 0;
        }

        rootView = getWindow().getDecorView().getRootView();
        rootView.setBackgroundColor(Color.YELLOW);

        imagenView = findViewById(R.id.imagen1);


        moneyAtrib = findViewById(R.id.tvMoney);
        moneyAtrib.setText("$" + money);

        questionOne = findViewById(R.id.tvPregunta1);

        bResposta1 = (Button) findViewById(R.id.bResposta1);
        bResposta2 = (Button) findViewById(R.id.bResposta2);
        bResposta3 = findViewById(R.id.bResposta3);
        bResposta4 = findViewById(R.id.bResposta4);

        bResposta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRespuestaClick(v);
            }
        });

        bResposta2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRespuestaClick(v);
            }
        });

        bResposta3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRespuestaClick(v);
            }
        });

        bResposta4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRespuestaClick(v);
            }
        });

            Button newAct = findViewById(R.id.button2);
        newAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onShowAnswerClick(v);
            }
        });

        showQuestions();
    }

    public void onShowAnswerClick(View view) {
        String answer = questions[id].getOption()[questions[id].getCorrect() - 1];
        Intent intent = new Intent(this, ComodiActivity.class);
        intent.putExtra("answer", answer);
        intent.putExtra("bool", answerShown);
        startActivity(intent);
        answerShown = "true";
    }

    private void showQuestions()
    {
        Question preguntaActual = questions[id];
        questionOne.setText(preguntaActual.getQuestion());
        if (id == 0)
        {
            imagenView.setImageResource(R.drawable.francia);
            bResposta1.setText(preguntaActual.getOption()[0]);
            bResposta2.setText(preguntaActual.getOption()[1]);
            bResposta3.setText(preguntaActual.getOption()[2]);
            bResposta4.setText(preguntaActual.getOption()[3]);
        }
        else if (id == 1)
        {
            imagenView.setImageResource(R.drawable.mapa);
            bResposta1.setText(preguntaActual.getOption()[0]);
            bResposta2.setText(preguntaActual.getOption()[1]);
            bResposta3.setText(preguntaActual.getOption()[2]);
            bResposta4.setText(preguntaActual.getOption()[3]);
        }
        else if (id == 2)
        {
            imagenView.setImageResource(R.drawable.mat);
            bResposta1.setText(preguntaActual.getOption()[0]);
            bResposta2.setText(preguntaActual.getOption()[1]);
            bResposta3.setText(preguntaActual.getOption()[2]);
            bResposta4.setText(preguntaActual.getOption()[3]);
        }
        else if (id == 3)
        {
            imagenView.setImageResource(R.drawable.madrid);
            bResposta1.setText(preguntaActual.getOption()[0]);
            bResposta2.setText(preguntaActual.getOption()[1]);
            bResposta3.setText(preguntaActual.getOption()[2]);
            bResposta4.setText(preguntaActual.getOption()[3]);
        }
    }

    @SuppressLint("NonConstantResourceId")
    public void onRespuestaClick(View view)
    {
        int idbutton = view.getId();
        int respuestaSeleccionada = 0;

        switch (idbutton)
        {
            case R.id.bResposta1:
                respuestaSeleccionada = 1;
                break;
            case R.id.bResposta2:
                respuestaSeleccionada = 2;
                break;
            case R.id.bResposta3:
                respuestaSeleccionada = 3;
                break;
            case R.id.bResposta4:
                respuestaSeleccionada = 4;
                break;
        }

        if (questions[id].getCorrect() == respuestaSeleccionada)
        {
            id++;
            money += 100;

            if (id == questions.length)
            {
                Toast.makeText(this, "¡Muy bien las acertaste todas!", Toast.LENGTH_SHORT).show();
                finish();
            }
            else
            {
                Toast.makeText(this, "¡Correcto!", Toast.LENGTH_SHORT).show();

                showQuestions();
                moneyAtrib.setText("$" + money);
            }
        }
        else
        {
            Toast.makeText(this, "¡Respuesta erronea!", Toast.LENGTH_SHORT).show();
            moneyAtrib.setText("$" + money);
        }

        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(money/(questions.length));
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        Log.d(TAG, "onStart() called");
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        Log.d(TAG, "onResume() called");
    }


    @Override
    protected void onSaveInstanceState(@NonNull Bundle savedInstanceState)
    {
        super.onSaveInstanceState(savedInstanceState);
        Log.d(TAG, "onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, id);
        savedInstanceState.putInt("money", money);
        savedInstanceState.putString("bool", answerShown);
    }

    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        money = savedInstanceState.getInt("money");
        moneyAtrib.setText("$" + money);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        Log.d(TAG, "onStop() called");
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }
}